#!/bin/bash
#
# backup_full.sh - Script de backup para el TP Integrador
#

# --- Funcion de ayuda ---
mostrar_ayuda() {
    echo "================================================================"
    echo " backup_full.sh - Script de backup"
    echo "================================================================"
    echo ""
    echo "Uso: $0 <origen> <destino>"
    echo ""
    echo "Realiza un backup comprimido (.tar.gz) del directorio de origen"
    echo "y lo almacena en el directorio de destino."
    echo ""
    echo "Argumentos:"
    echo "  <origen>    Directorio a backupear (ejemplo: /var/log)"
    echo "  <destino>   Directorio donde guardar el backup (ej: /backup_dir)"
    echo ""
    echo "Opciones:"
    echo "  -help       Muestra esta ayuda"
    echo ""
    echo "Ejemplo:"
    echo "  $0 /var/log /backup_dir"
    echo ""
    echo "El archivo generado tendra el formato:"
    echo "  <nombre>_bkp_YYYYMMDD.tar.gz"
    echo "================================================================"
}

# --- Opcion de ayuda ---
if [ "$1" = "-help" ] || [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
    mostrar_ayuda
    exit 0
fi

# --- Validar cantidad de argumentos ---
if [ "$#" -ne 2 ]; then
    echo "ERROR: Se requieren exactamente 2 argumentos (origen y destino)."
    echo "Use '$0 -help' para ver la ayuda."
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"

# --- Validar que el filesystem de origen este disponible ---
if [ ! -d "$ORIGEN" ]; then
    echo "ERROR: El origen '$ORIGEN' no existe o su filesystem no esta disponible."
    exit 1
fi

# --- Validar que el destino exista ---
if [ ! -d "$DESTINO" ]; then
    echo "ERROR: El destino '$DESTINO' no existe."
    exit 1
fi

# --- Validar que el filesystem de destino este montado ---
if ! mountpoint -q "$DESTINO"; then
    echo "ERROR: El filesystem de destino '$DESTINO' no esta montado."
    exit 1
fi

# --- Generar nombre con fecha en formato ANSI (YYYYMMDD) ---
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

# --- Realizar el backup ---
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Iniciando backup de '$ORIGEN'..."
tar -czf "$DESTINO/$ARCHIVO" -C "$(dirname "$ORIGEN")" "$NOMBRE"

# --- Verificar resultado ---
if [ "$?" -eq 0 ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Backup OK: $DESTINO/$ARCHIVO"
    exit 0
else
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: Fallo el backup."
    exit 1
fi
