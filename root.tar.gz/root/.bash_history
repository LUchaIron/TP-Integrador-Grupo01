apt update
sed -i '/bullseye/bookworm/g' /etc/apt/source.list
sed -i 's/bullseye/bookworm/g' /etc/apt/source.list
sed -i 's/bullseye/bookworm/g' /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
apt full-upgrade -y
reboot
cat > /etc/network/interfaces << 'EOF'
# Network interfaces

source /etc/network/interfaces.d/*

auto lo
iface lo inet loopback

auto enp0s1
iface enp0s1 inet static
    address 192.168.0.50
    netmask 255.255.255.0
    gateway 192.168.0.1
    dns-nameservers 8.8.8.8 1.1.1.1
EOF

cat /etc/network/interfaces
systemctl restart networking
systemctl status networking.service --no-pager -l
journalctl -xeu networking.service --no-pager | tail -30
cp /etc/network/interfaces /etc/network/interfaces.bak
nano /etc/network/interfaces
systemctl restart networking
ip a show enp0s1
sed -i 's/#*PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config
sed -i 's/#*PasswordAuthentication.*/PasswordAuthentication yes/' /etc/ssh/sshd_config
systemctl restart ssh
systemctl status ssh
ip addr flush dev enp0s1
ip route flush dev enp0s1
ifup enp0s1
ip a show enp0s1
ping -c 3 google.com
poweroff
echo "el copy-paste funciona"
ssh-keygen -t ed25519 -f /root/.ssh/id_ed25519 -N "" -C "root@TPServer"
cat /root/.ssh/id_ed25519.pub >> /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys
chmod 700 /root/.ssh
ls -la /root/.ssh/
ssh -o BatchMode=yes root@localhost "echo LOGIN CON CLAVE OK"
ssh -o BatchMode=yes root@localhost "echo LOGIN CON CLAVE OK"
ssh -o BatchMode=yes -o StrictHostKeyChecking=accept-new root@localhost "echo LOGIN CON CLAVE OK"
